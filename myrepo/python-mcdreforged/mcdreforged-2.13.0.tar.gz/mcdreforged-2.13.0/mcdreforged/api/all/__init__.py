"""
For lazy man
"""

# noinspection PyUnresolvedReferences
from mcdreforged.api.command import *
# noinspection PyUnresolvedReferences
from mcdreforged.api.decorator import *
# noinspection PyUnresolvedReferences
from mcdreforged.api.event import *
# noinspection PyUnresolvedReferences
from mcdreforged.api.exception import *
# noinspection PyUnresolvedReferences
from mcdreforged.api.rcon import *
# noinspection PyUnresolvedReferences
from mcdreforged.api.rtext import *
# noinspection PyUnresolvedReferences
from mcdreforged.api.types import *
# noinspection PyUnresolvedReferences
from mcdreforged.api.utils import *
