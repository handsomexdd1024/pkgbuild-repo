# -----------------------------------------------------------------------
# |  In plugin environment, import modules inside mcdreforged.api only  |
# -----------------------------------------------------------------------
# The api collection for plugins
