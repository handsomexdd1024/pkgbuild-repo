from mcdreforged.constants import core_constant as __core_constant

__version__ = __core_constant.VERSION_PYPI
