from typing import Union

JsonLike = Union[None, int, float, str, bool, list, dict]
